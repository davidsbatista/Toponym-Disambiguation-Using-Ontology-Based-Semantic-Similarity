This is a collection of Portuguese news articles part of the CHAVE collection (http://www.linguateca.pt/chave/), the articles have the toponyms annotated to geographic concetps in Geo-Net-PT02.


* The follwing files have just one toponym per article:

PUBLICO-19950102-046.xml
PUBLICO-19950106-064.xml
PUBLICO-19950107-108.xml
PUBLICO-19950108-040.xml



* The follwing files have articles on which there are no direct string matches between the name of the toponym in the article and the name of the geographic concept in Geo-Net-PT02, for instances: 

- "Rossio" is the popular name of the "Praça de D. Pedro IV"
- "Belém" is a common abbrevation for the civil parish of "Santa Maria de Belém"

PUBLICO-19940401-051.xml
PUBLICO-19940401-088.xml
PUBLICO-19940401-095.xml
PUBLICO-19940401-098.xml
PUBLICO-19940402-042.xml
PUBLICO-19940402-096.xml
PUBLICO-19940404-041.xml
PUBLICO-19940404-095.xml
PUBLICO-19940418-045.xml
PUBLICO-19940418-047.xml
PUBLICO-19940801-052.xml
PUBLICO-19940826-070.xml
PUBLICO-19950104-051.xml
PUBLICO-19950104-055.xml
PUBLICO-19950105-074.xml
PUBLICO-19950105-077.xml
PUBLICO-19950106-094.xml
